@extends('layouts.app')
@section('content')
<h1>Ini index</h1>
@endsection
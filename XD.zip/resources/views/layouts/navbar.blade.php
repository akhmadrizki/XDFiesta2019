<h1>Ini navbar</h1><br>
<a href="/lomba/create">Input Lomba</a> 
<a href="/lomba">Tampil Lomba</a>
@extends('layouts.main')

@section('title')
	<title>Concert in STMIK Primakara - XD Events & Competitions - XD Fiesta 2019</title>
@endsection

@section('content')
	<h1>Coming Soon...</h1>
@endsection
@extends('layouts.main')

@section('title')
	<title>XD Fiesta 2019 - Homepage</title>
@endsection

@section('content')
	<h1>Coding here...</h1>
@endsection
@extends('layouts.main')

@section('title')
	<title>XD Gallery - XD Fiesta 2019</title>
@endsection

@section('content')
	<h1>Who? coding here...</h1>
@endsection
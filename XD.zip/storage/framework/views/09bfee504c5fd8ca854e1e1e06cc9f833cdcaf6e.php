<?php $__env->startSection('content'); ?>

<div class="section-header">
            <h1>List Konten</h1>
</div>

<div class="section-body">
<div class="card">
<div class="card-body">
	<p>
		<a href="<?php echo e(route('lomba.index')); ?>" class="list-group-item list-group-item-action">
		Lomba</a>
	</p>
	<p>
		<a href="/blank.html" class="list-group-item list-group-item-action">
		Event</a>
	</p>
	<p>
		<a href="/blank.html" class="list-group-item list-group-item-action">
		Daftar</a>
	</p>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/admin/list.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Login &mdash; Stisla</title>

  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo e(asset('adminDashboard/modules/bootstrap/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('adminDashboard/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('adminDashboard/css/components.css')); ?>">
<!-- Start GA -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-94034622-3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-94034622-3');
</script>
<!-- /END GA -->
</head>

<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
            <div class="login-brand">
              <a href="/"><img src="<?php echo e(asset('adminDashboard/img/xd.png')); ?>" alt="logo-xd" width="100" class="shadow-light rounded-circle"></a>
            </div>

            <div class="card card-primary">
              <div class="card-header"><h4><?php echo e(__('Login')); ?></h4></div>

              <div class="card-body">

                <form method="POST" action="<?php echo e(route('login')); ?>" class="needs-validation">
                  <?php echo csrf_field(); ?>

                  <div class="form-group">
                    <label for="email"><?php echo e(__('Email')); ?></label>
                    <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" tabindex="1" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>

                  <div class="form-group">
                    <div class="d-block">
                    	<label for="password" class="control-label"><?php echo e(__('Password')); ?></label>
                      <div class="float-right">
                        <?php if(Route::has('password.request')): ?>
                          <a href="<?php echo e(route('password.request')); ?>" class="text-small">
                              <?php echo e(__('Forgot Your Password?')); ?>

                          </a>
                        <?php endif; ?>
                      </div>
                    </div>
                    <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" tabindex="2" required autocomplete="current-password">
                    
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                  </div>

                  <div class="form-group">
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" name="remember" class="custom-control-input" tabindex="3" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                      <label class="custom-control-label" for="remember"><?php echo e(__('Remember Me')); ?></label>
                    </div>
                  </div>

                  <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                      <?php echo e(__('Login')); ?>

                    </button>
                  </div>

                </form>

              </div>
            </div>
            
            <div class="simple-footer">
              Copyright XD Fiesta &copy; <?php echo e(date("Y")); ?> <div class="bullet"></div> All Rights Reserved
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

</body>
</html><?php /**PATH D:\ProjectWeb\XD\resources\views/layouts/loginPage.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
	<div class="xd-profile">
		<div class="container">
			<div class="row">
				<div class="col column xd-about">
					<div class="xd-about-text">
						<p style="margin:0;text-align:center;">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex ullam, voluptates eum. Ipsum aspernatur et ad quod voluptatem, accusamus perspiciatis aliquam. Quis libero eum sit laborum ut, mollitia dicta in eligendi ab odio quia repudiandae, soluta est nisi cumque veniam commodi corporis repellendus officiis animi aliquam ipsam!</p>
					</div>
					<div class="xd-about-video" style="text-align:center;">
						<iframe width="100%" height="100%	" src="https://www.youtube.com/embed/f_dBvjFlQ3Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/client/pages/xd-profile.blade.php ENDPATH**/ ?>
<nav id="navbar">
	<section>
		<div class="row">
			<div class="col-6 column">
				<a href="/" class="juduls"><h1 style="margin:0;">XD Fiesta 2019</h1></a>
			</div>
			<div class="col-6 column" style="text-align:right;">
				<span id="dropdown-trigger"><i class="material-icons">menu</i></span>
				<div class="nav-item" id="nav-item">
					<!-- <a href="/xd-profile" class="nav-link <?php echo e($navActive == 'profile' ? 'active' : NULL); ?>">XD Profile</a> -->
					<a href="/xd-events-and-competitions" class="nav-link <?php echo e($navActive == 'events' ? 'active' : NULL); ?>">XD Events & Competitions</a>
					<!-- <a href="/xd-gallery" class="nav-link <?php echo e($navActive == 'gallery' ? 'active' : NULL); ?>">XD Gallery</a> -->
				</div>
			</div>
		</div>
	</section>
	<?php if(isset($subnavActive)): ?>
		<section>
			<div class="row">
				<div class="col column">
					<div class="subnav-item">
						<!-- <a href="/xd-events-and-competitions/main-event" class="subnav-link <?php echo e($subnavActive == 'main-event' ? 'active' : NULL); ?>">Main Event</a> -->
						<?php $__currentLoopData = $inilomba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lomba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
							$path=str_replace(' ', '-', $lomba->judul_nav)
						?>
						<a <?php echo e($lomba->pdf == null ? null : "href=" . action('PagesController@show',$path)); ?> class="subnav-link <?php echo e($subnavActive == $lomba->judul_nav ? 'active' : NULL); ?>"><?php echo e($lomba->judul_nav); ?></a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
						
						
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>
</nav>
<div id="navbar-gap"></div><?php /**PATH D:\ProjectWeb\XD\resources\views/client/components/navbar.blade.php ENDPATH**/ ?>
<footer>
	<div class="container-fluid">
		<!-- <div class="row">
			<div class="col-12 col-sm-6 column">
				<ul class="nav-link-list">
					<li><a href="/xd-events-and-competitions/main-event">Concert in STMIK Primakara</a></li>
					<?php $__currentLoopData = $inilomba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lomba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
							$path=str_replace(' ', '-', $lomba->judul_nav)
						?>
						<li><a href="<?php echo e(action('PagesController@show',$path)); ?>"><?php echo e($lomba->judul_nav); ?> Competition</a></li>
						
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					
				</ul>
			</div>
		</div> -->
		<div class="row">
			<div class="col-12 col-sm-6 column" style="text-align:center;">
				<span class="title">XD Fiesta 2019 - STMIK Primakara</span>
			</div>
			<div class="col-12 col-sm-6 column">
				<div class="social-medias" style="text-align:center;">
					<a href="https://web.facebook.com/primakara/?_rdc=1&_rdr" target="_blank" class="social-media-item">
						<img src="<?php echo e(asset('images/compressed/facebook.png')); ?>" alt="Facebook" width="25">
					</a>
					<a href="https://www.instagram.com/stmik_primakara/?igshid=14c3rqrooqft9" target="_blank" class="social-media-item">
						<img src="<?php echo e(asset('images/compressed/instagram.png')); ?>" alt="Instagram" width="25">
					</a>
				</div>
			</div>
		</div>
	</div>
</footer><?php /**PATH D:\ProjectWeb\XD\resources\views/client/components/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="section-header">
            <h1>Input Syarat dan Ketentuan</h1>
</div>

<div class="section-body">
    <div class="card">
        <div class="card-body">
            <form method="post" action="<?php echo e(action('Content\SyaratController@store')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id_lomba" value="<?php echo e($lomba->id_lomba); ?>">
            <h6>Syarat dan Ketentuan <?php echo e($lomba->judul); ?> </h6><br/>
            <textarea name="deskripsi" class="summernote-simple" style="display: none;" ></textarea>
                <div class="text-right">
                <?php if($next=='next'): ?>
                <input type="hidden" name="next" value="next">
                <?php elseif($next=='show'): ?>
                <input type="hidden" name="next" value="show">
                <?php endif; ?>
                <input type="submit" value="Tambah" class="btn btn-success">
                <?php if($next=='next'): ?>
                <a href="<?php echo e(action('Content\KetentuanPesertaController@create')); ?>" class="btn btn-primary">Lanjut</a>
                <?php elseif($next=='show'): ?>
                <a href="<?php echo e(action('Content\LombaController@show',$lomba->id_lomba)); ?>" class="btn btn-primary">Selesai</a>
                <?php endif; ?>
                </div>
            </form>
        </div>
    
    <ul class="list-group list-group-flush">
    <?php $__currentLoopData = $inisyarat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $syarat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item">
        <?php echo $syarat->deskripsi; ?>

    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/admin/syarat/create.blade.php ENDPATH**/ ?>
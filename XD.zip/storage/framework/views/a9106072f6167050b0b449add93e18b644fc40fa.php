<?php $__env->startSection('content'); ?>
	<h1>Arya coding here...</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/client/pages/xd-events.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="section-header">
            <h1>Input Waktu dan Tempat</h1>
</div>

<div class="section-body">
    <div class="card">
        <div class="card-body">
        <form method="post" action="<?php echo e(action('Content\WaktuTempatController@store')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id_lomba" value="<?php echo e($lomba->id_lomba); ?>">
            <h6>Waktu dan Tempat <?php echo e($lomba->judul); ?> </h6><br/>
            <div class="form-group">
                    <label>Technical Meeting</label>
                    <input type="text" class="form-control" name="tm">
            </div>
            <div class="form-group">
                    <label>Tempat Technical Meeting</label>
                    <input type="text" class="form-control" name="tempat_tm">
            </div>
            <div class="form-group">
                    <label>Waktu Lomba</label>
                    <input type="text" class="form-control" name="waktu">
            </div>
            <div class="form-group">
                    <label>Tempat Lomba</label>
                    <input type="text" class="form-control" name="tempat">
            </div>
            <div class="text-right">
                 <?php if($next=='next'): ?>
                <input type="hidden" name="next" value="next">
                <input type="submit" value="Lanjut" class="btn btn-primary">
                <?php elseif($next=='show'): ?>
                <input type="hidden" name="next" value="show">
                <input type="submit" value="Selesai" class="btn btn-primary">
                <?php endif; ?>
            </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/admin/waktu_tempat/create.blade.php ENDPATH**/ ?>
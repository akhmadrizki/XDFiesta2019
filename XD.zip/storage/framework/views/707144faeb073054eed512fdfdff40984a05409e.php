<?php $__env->startSection('title'); ?>
	<title>XD Events & Competitions - XD Fiesta 2019</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<main class="xd-events-main">
		<div class="xd-events-banner" style="background-image:url(<?php echo e(asset('images/compressed/white-xd-events-and-competitions.png')); ?>);background-size:cover;background-repeat:no-repeat;">
			<div class="container">
				<div class="row align-items-center">
					<div class="col column">
						<h2>XD Events & Competitions</h2>
						<p>Jangan lewatkan keseruan serta kehebohan <br> XD Events & Competitions bersama kami!</p>
					</div>
				</div>
			</div>
		</div>
		<div class="xd-events-banner banner-fit" style="background-image:url(<?php echo e(asset('images/compressed/concert/concert.jpg')); ?>);"></div>
		<div class="xd-events-collection">
			<div class="container">
				<div class="row">
					<div class="col column">
						<h2>XD Events</h2>
						<div class="xd-main-event">
							<img src="" alt="">
							<div class="xd-main-event-overlay">
								<div class="xd-main-event-overlay-info">
									<p class="label">Main Event</p>
									<h2>XD Fiesta Concert in STMIK Primakara</h2>
								</div>
								<!-- <a class="action" href="/xd-events-and-competitions/main-event">See Details</a> -->
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col column">
						<h2>XD Competitions</h2>
						<div class="xd-competitions-event">
							<div class="row">
								<?php if(count($data)>0): ?>
								<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-12 col-lg-6 column">
								<div class="card" style="margin-bottom:20px">
									<div class="card-image">
										<img src="<?php echo e(url('uploads/'.$dword->thumbnail)); ?>" width="300px" alt="">
									</div>

									<div class="card-content">
										<p class="card-label">Competition</p>
										<h2 class="card-title"><?php echo e($dword->judul); ?></h2>
										<p class="card-date"><?php echo e(isset($dword->waktu)?$dword->waktu:''); ?></p>
										<?php
											$path_name=str_replace(' ', '-', $dword->judul_nav);
										?>
										<?php if($dword->waktu != 'Coming Soon'): ?>
											<a href="<?php echo e(action('PagesController@show',$path_name)); ?>" class="card-action">See Details</a>
										<?php else: ?>
											<a class="card-action" style="color:#777;">Coming Soon</a>
										<?php endif; ?>
									</div>
								</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							<?php else: ?>
							<p>Lomba tidak tersedia</p>
							<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="xd-events-banner banner-fit" style="background-image:url(<?php echo e(asset('images/compressed/concert/concert2.jpg')); ?>);"></div>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/client/pages/xd-events-and-competitions.blade.php ENDPATH**/ ?>
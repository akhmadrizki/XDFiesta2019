<?php $__env->startSection('content'); ?>

<div class="section-header">
            <h1>Input Kontak</h1>
</div>

<div class="section-body">
    <div class="card">
        <div class="card-body">
                <form method="post" action="<?php echo e(action('Content\KontakController@store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_lomba" value="<?php echo e($lomba->id_lomba); ?>">
                <h6>Kontak <?php echo e($lomba->judul); ?> </h6><br/>
                <div class="form-group">
                        <label>Kontak</label>
                        <input type="text" class="form-control" name="kontak">
                </div>
                <div class="text-right">
                <?php if($next=='next'): ?>
                <input type="hidden" name="next" value="next">
                <?php elseif($next=='show'): ?>
                <input type="hidden" name="next" value="show">
                <?php endif; ?>
                <input type="submit" value="Tambah" class="btn btn-success">
                <?php if($next=='next'): ?>
                <a href="<?php echo e(action('Content\HadiahController@create')); ?>" class="btn btn-primary">Lanjut</a>
                <?php elseif($next=='show'): ?>
                <a href="<?php echo e(action('Content\LombaController@show',$lomba->id_lomba)); ?>" class="btn btn-primary">Selesai</a>
                <?php endif; ?>
                </div>
            </form>
        </div>
    
    <ul class="list-group list-group-flush">
    <?php $__currentLoopData = $inikontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kontak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item">
        <?php echo e($kontak->kontak); ?>

    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/admin/kontak/create.blade.php ENDPATH**/ ?>
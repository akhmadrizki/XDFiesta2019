<?php $__env->startSection('content'); ?>

<div class="section-header">
            <h1>List Lomba</h1>
</div>

<div class="section-body">
    <div>
    </div>
    <div class="card">
    <div class="card-body">
	<div class="row">
    <?php if(count($data)>0): ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-12 col-lg-6 column">
        <div class="card">
            <div class="card-image">
                <img src="<?php echo e(url('uploads/'.$dword->thumbnail)); ?>" width="200px" alt="">
            </div>
            <div class="card-content">
                <p class="card-label">Competition</p>
                <h2 class="card-title"><?php echo e($dword->judul); ?></h2>
                <p class="card-date"><?php echo e(isset($dword->waktu)?$dword->waktu:''); ?></p>
            </div>
            <a href="<?php echo e(action('Content\LombaController@show',$dword->id_lomba)); ?>"
             class="card-action">See Details</a>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
    <p>Lomba tidak tersedia</p>
    <?php endif; ?>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/admin/lomba/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="section-header">
            <h1>Input Hadiah</h1>
</div>

<div class="section-body">
    <div class="card">
        <div class="card-body">
        <form method="post" action="<?php echo e(action('Content\HadiahController@store')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id_lomba" value="<?php echo e($lomba->id_lomba); ?>">
            <h6>Hadiah <?php echo e($lomba->judul); ?> </h6><br/>
            <input type="text" name="deskripsi" class="form-control"><br/>
            <div class="text-right">
            <input type="submit" value="Tambah" class="btn btn-success">
            <a href="<?php echo e(action('Content\LombaController@show',$lomba->id_lomba)); ?>" 
            class="btn btn-primary">Selesai</a>
            </div>
        </form>
        </div>
    
    <ul class="list-group list-group-flush">
    <?php $__currentLoopData = $inihadiah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hadiah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item">
        <?php echo $hadiah->deskripsi; ?>

    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/admin/hadiah/create.blade.php ENDPATH**/ ?>
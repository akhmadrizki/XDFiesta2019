<?php $__env->startSection('content'); ?>

<div class="section-header">
            <h1>Edit Lomba</h1>
</div>

<div class="section-body">
    <div class="card">
    <div class="card-body">
    <form method="post" action="<?php echo e(action('Content\LombaController@update')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id_lomba" value="<?php echo e($lomba->id_lomba); ?>">
        <div class="form-group">
            <label>Judul Lomba</label>
            <input type="text" class="form-control" name="judul" value="<?php echo e($lomba->judul); ?>">
        </div>
        <div class="form-group">
            <label>Judul Navigator Lomba</label>
            <input type="text" class="form-control" name="judul_nav" value="<?php echo e($lomba->judul_nav); ?>">
        </div>
        <div class="form-group">
            <label>Deskripsi</label>
            <textarea class="summernote-simple" style="display: none;" name="deskripsi">
                 <?php echo $lomba->deskripsi; ?>

            </textarea>
        <div class="form-group">
            <label>Header Picture</label><br>
            <input type="file" name="pic">
        </div>
        <div class="form-group">
            <label>Thumbnail Picture</label><br>
            <input type="file" name="thumbnail">
        </div>
        <div class="form-group">
            <label>File syarat .pdf</label><br>
            <input type="file" name="pdf"><br/>
            <i>Masukan file .pdf disini</i>
        </div>
        <div class="card-footer text-right">
            <input type="submit" value="Edit" class="btn btn-warning">
        </div>
    </form>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/admin/lomba/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="section-header">
            <h1><?php echo e($lomba->judul); ?></h1>
</div>

<div class="section-body">
    <div class="card">
    <div class="card-body">
    <div>
        Header Picture<br/>
        <?php if($lomba->pic!=null): ?>
        <img src="<?php echo e(url('uploads/'.$lomba->pic)); ?>" width="400px"/>
        <?php else: ?>
        <i>Foto tidak tersedia</i>
        <?php endif; ?>
    </div>
    <br/>
    <div>
        Thumbnail Picture<br/>
        <?php if($lomba->thumbnail!=null): ?>
        <img src="<?php echo e(url('uploads/'.$lomba->thumbnail)); ?>" width="200px"/>
        <?php else: ?>
        <i>Foto tidak tersedia</i>
        <?php endif; ?>
    </div>
    <br/>
    <div>
        File syarat .pdf<br/>
        <?php if($lomba->pdf!=null): ?>
        
        
        <?php
        $file=str_replace(' ', '-', $lomba->pdf);
        ?>
        <a href="download/<?php echo e($file); ?>" class="btn btn-sm btn-primary" target="_blank">Download</a>
        <?php else: ?>
        <i>File tidak tersedia</i>
        <?php endif; ?>
    </div>
    <p>
    Judul di navigator : <?php echo $lomba->judul_nav?$lomba->judul_nav:'<i>Kosong</i>'; ?><br/>
    Deskripsi : <?php echo $lomba->deskripsi; ?>

    </p>
    <form action="<?php echo e(route('lomba.destroy', $lomba->id_lomba)); ?>" method="post">
    <a href="<?php echo e(action('Content\LombaController@edit',$lomba->id_lomba)); ?>" class="btn btn-sm btn-warning">
    Edit</a>
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
    </form><br/>
    <div>
        <h6>Persyaratan Pendaftaran</h6>
        <a href="<?php echo e(action('Content\SyaratController@show',$lomba->id_lomba)); ?>" 
        class="btn btn-sm btn-success">Tambah</a>
    </div>
    <div>
    <ul class="list-group list-group-flush">
    <?php $__currentLoopData = $syarat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item">
        <div>
        <?php echo $sword->deskripsi; ?>

        <form action="<?php echo e(route('syarat.destroy',$sword->id_syarat)); ?>" method="post">
        <a href="<?php echo e(action('Content\SyaratController@edit',$sword->id_syarat)); ?>"  class="btn btn-sm btn-warning">
            Edit
        </a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </div>
        </form>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <br/><br/>

    <h6>Ketentuan Khusus Peserta</h6>
        <a href="<?php echo e(action('Content\KetentuanPesertaController@show',$lomba->id_lomba)); ?>" 
        class="btn btn-sm btn-success">Tambah</a>
    </div>
    <div>
    <ul class="list-group list-group-flush">
    <?php $__currentLoopData = $ketentuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item">
        <div>
        <?php echo $kword->deskripsi; ?>

        <form action="<?php echo e(route('ketentuan_peserta.destroy',$kword->id_ketentuan_peserta)); ?>" method="post">
        <a href="<?php echo e(action('Content\KetentuanPesertaController@edit',$kword->id_ketentuan_peserta)); ?>"
        class="btn btn-sm btn-warning">
            Edit
        </a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </div>
        </form>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <br/><br/>
    
    <h6>Kriteria Penilaian</h6>
        <a href="<?php echo e(action('Content\PenilaianController@show',$lomba->id_lomba)); ?>" 
        class="btn btn-sm btn-success">Tambah</a>
    </div>
    <div>
    <ul class="list-group list-group-flush">
    <?php $__currentLoopData = $penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item">
        <div>
        <?php echo $pword->deskripsi; ?>

        <form action="<?php echo e(route('penilaian.destroy',$pword->id_penilaian)); ?>" method="post">
        <a href="<?php echo e(action('Content\PenilaianController@edit',$pword->id_penilaian)); ?>"
        class="btn btn-sm btn-warning">
            Edit
        </a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </div>
        </form>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <br/><br/>
    
    <h6 style="display:inline-block;margin-right:10px">Waktu dan Tempat Lomba</h6><br/>
    <?php if($waktu!="null"): ?>
    <div>
        <p>
            Technical Meeting : <?php echo e($waktu->tm); ?><br/>
            Tempat Technical Meeting : <?php echo e($waktu->tempat_tm); ?><br/>
            Waktu : <?php echo e($waktu->waktu); ?><br/>
            Tempat : <?php echo e($waktu->tempat); ?><br/>
        </p>
    </div>
    <?php endif; ?>
    <?php if($waktu=="null"): ?>
        <a href="<?php echo e(action('Content\WaktuTempatController@show',$lomba->id_lomba)); ?>"
        class="btn btn-sm btn-success">
            Tambah
        </a>
        <?php else: ?>
        <a href="<?php echo e(action('Content\WaktuTempatController@edit',$waktu->id_waktu_tempat)); ?>"
        class="btn btn-sm btn-warning">
            Edit
        </a>
    <?php endif; ?>
    <br/><br/>
    
    <h6>Kontak</h6>
        <a href="<?php echo e(action('Content\KontakController@show',$lomba->id_lomba)); ?>" 
        class="btn btn-sm btn-success">Tambah</a>
    <div>
    <ul class="list-group list-group-flush">
    <?php if(isset($kontak)): ?>
    <?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item">
        <div>
        <?php echo $kword->kontak; ?>

        <form action="<?php echo e(route('kontak.destroy',$kword->id_kontak)); ?>" method="post">
        <a href="<?php echo e(action('Content\KontakController@edit',$kword->id_kontak)); ?>"
        class="btn btn-sm btn-warning">
            Edit
        </a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </div>
        </form>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </ul>
    <br/><br/>

    <h6>Hadiah</h6>
        <a href="<?php echo e(action('Content\HadiahController@show',$lomba->id_lomba)); ?>" 
        class="btn btn-sm btn-success">Tambah</a>
    <div>
    <ul class="list-group list-group-flush">
    <?php if(isset($hadiah)): ?>
    <?php $__currentLoopData = $hadiah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item">
        <div>
        <?php echo $hword->deskripsi; ?>

        <form action="<?php echo e(route('hadiah.destroy',$hword->id_hadiah)); ?>" method="post">
        <a href="<?php echo e(action('Content\HadiahController@edit',$hword->id_hadiah)); ?>"
        class="btn btn-sm btn-warning">
            Edit
        </a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </div>
        </form>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </ul>

    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectWeb\XD\resources\views/admin/lomba/show.blade.php ENDPATH**/ ?>
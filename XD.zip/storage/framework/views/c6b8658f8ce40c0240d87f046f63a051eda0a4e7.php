<table>
	<thead>
		<tr>
			<th>Jumlah Peserta</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>XD Fiesta 2019</td>	
		</tr>
	</tbody>
</table>

<table>
    <thead>
    <tr>
        <th>Nama Team</th>
        <th>Nama Ketua</th>
        <th>No. Whatsapp</th>
        <th>Lomba</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($lm->nama_team); ?></td>
            <td><?php echo e($lm->nama_ketua); ?></td>
            <td><?php echo e($lm->no_wa); ?></td>
            <td><?php echo e($lm->judul_lomba); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\ProjectWeb\XD\resources\views/export/index.blade.php ENDPATH**/ ?>
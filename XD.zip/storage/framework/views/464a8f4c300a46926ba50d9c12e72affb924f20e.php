<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php echo $__env->yieldContent('title'); ?>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons|Sarabun|Roboto">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-grid.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-reboot.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
</head>
<body>
	<?php echo $__env->make('client.components.navbar-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('content'); ?>
	<?php echo $__env->make('client.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<script src="<?php echo e(asset('js/main-2.js')); ?>"></script>
</body>
</html><?php /**PATH D:\ProjectWeb\XD\resources\views/layouts/main-2.blade.php ENDPATH**/ ?>
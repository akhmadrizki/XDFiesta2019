<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WaktuTempat extends Model
{
    public $table = 'waktu_tempat';
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KetentuanPeserta extends Model
{
    public $table = 'ketentuan_peserta';
}
